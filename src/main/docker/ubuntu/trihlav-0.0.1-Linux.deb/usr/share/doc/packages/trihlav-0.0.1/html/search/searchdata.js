var indexSectionsWithContent =
{
  0: "abcdefghiklmoprstuvwy~",
  1: "abcefkmpsuvwy",
  2: "t",
  3: "acdghiklmorsuwy~",
  4: "fst",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs"
};

