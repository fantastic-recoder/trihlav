var searchData=
[
  ['spinboxiface',['SpinBoxIface',['../classtrihlav_1_1_spin_box_iface.html',1,'trihlav']]],
  ['streditiface',['StrEditIface',['../structtrihlav_1_1_str_edit_iface.html',1,'trihlav']]]
];
